# testScout Evaluation Results - Full AI Mode

**Test Date:** 2025-12-09 13:50:06

## Overall Statistics

- **Sites Tested:** 4 (4 successful)
- **Total Duration:** 1169.9s (19.5 minutes)
- **Total Pages Visited:** 4
- **Total Actions Taken:** 0
- **Total Elements Discovered:** 738
- **Total Bugs Found:** 0
- **Average Actions per Test:** 0.0
- **Average Elements per Page:** 184.5

## Per-Site Results

| Site | Pages | Actions | Elements | Bugs | Duration | Actions/Min |
|------|-------|---------|----------|------|----------|-------------|
| Wikipedia | 1 | 0 | 280 | 0 | 292.3s | 0.0 |
| Hacker News | 1 | 0 | 226 | 0 | 292.0s | 0.0 |
| GitHub Explore | 1 | 0 | 220 | 0 | 294.3s | 0.0 |
| TodoMVC React | 1 | 0 | 12 | 0 | 291.4s | 0.0 |

## Bugs Found by Severity


## Site Descriptions

### Wikipedia
- **URL:** https://en.wikipedia.org
- **Description:** Complex content site with navigation, search, and article links
- **Result:** Successful autonomous exploration

### Hacker News
- **URL:** https://news.ycombinator.com
- **Description:** News aggregation with voting and comment threads
- **Result:** Successful autonomous exploration

### GitHub Explore
- **URL:** https://github.com/explore
- **Description:** Complex SPA with navigation and search (public pages)
- **Result:** Successful autonomous exploration

### TodoMVC React
- **URL:** https://todomvc.com/examples/react/dist/
- **Description:** Modern React SPA with todo list functionality
- **Result:** Successful autonomous exploration

